import { type Dependency } from "../dependency/dep_factory";
import { type GraphEdge } from "./edge";

export class GraphNode {
    private _id: number;
    /*
    This value can be:
    - [AST, CFG] for starter nodes
    - Type of AST statement, for AST nodes
    - CFG_F_START, CFG_END, CFG_IF_END, CFG_WHILE_END, CFG_TRY_STMT_END, FOR_END, for CFG nodes
     */
    private _type: string;
    private _obj: any;
    private _edges: GraphEdge[];
    // This value represents the identifier of the node for CFG nodes (Program, ArrowFunctionExpression, FunctionDeclaration, FunctionExpression, LabeledStatement)
    private _identifier: string | null;
    // This value represents the namespace for start/end CFG nodes (__main__, #n_anon) - same as __functionName__
    private _namespace: string | null;
    // This value represents the name of the function for function CFG nodes (ArrowFunctionExpression, FunctionDeclaration, FunctionExpression, LabeledStatement)
    private _functionName: string | null;
    // This value represents the id of the start CFG node for the flow
    private _functionContext: number;
    // This value represents the id of the graph node that contains the function declaration
    private _functionNodeId: number;
    private _internalStructure: any;
    private _used: boolean;
    private _cfgEndNodeId: number;
    private _writeAllSubObjects: Dependency[];
    private _paramOrigin: boolean;

    constructor(id: number, type: string, obj = {}) {
        this._id = id;
        this._type = type;
        this._obj = obj;
        this._edges = [];
        this._identifier = null;
        this._namespace = null;
        this._functionName = null;
        this._functionContext = 0;
        this._functionNodeId = -1;
        this._internalStructure = null;
        this._used = false;
        this._cfgEndNodeId = -1;
        this._writeAllSubObjects = [];
        this._paramOrigin = false;
    }

    get id(): number {
        return this._id;
    }

    get type(): string {
        return this._type;
    }

    get obj(): any {
        return this._obj;
    }

    set obj(obj) {
        this._obj = obj;
    }

    get edges(): GraphEdge[] {
        return this._edges;
    }

    get identifier(): string | null {
        return this._identifier;
    }

    set identifier(identifierStr) {
        this._identifier = identifierStr;
    }

    get namespace(): string | null {
        return this._namespace;
    }

    set namespace(namespace) {
        this._namespace = namespace;
    }

    get functionName(): string | null {
        return this._functionName;
    }

    set functionName(name) {
        this._functionName = name;
    }

    get functionContext(): number {
        return this._functionContext;
    }

    set functionContext(id) {
        this._functionContext = id;
    }

    get functionNodeId(): number {
        return this._functionNodeId;
    }

    set functionNodeId(id) {
        this._functionNodeId = id;
    }

    get internalStructure(): any {
        return this._internalStructure;
    }

    set internalStructure(struct) {
        this._internalStructure = struct;
    }

    get used(): boolean {
        return this._used;
    }

    get cfgEndNodeId(): number {
        return this._cfgEndNodeId;
    }

    set cfgEndNodeId(id: number) {
        this._cfgEndNodeId = id;
    }

    get writeAllSubObjects(): Dependency[] {
        return this._writeAllSubObjects;
    }

    get paramOrigin(): boolean {
        return this._paramOrigin;
    }

    set paramOrigin(value: boolean) {
        this._paramOrigin = value;
    }

    addWriteAllSubObjects(dep: Dependency): void {
        this._writeAllSubObjects.push(dep);
    }

    setUsed(): void {
        this._used = true;
    }

    addEdge(edge: GraphEdge): void {
        this._edges.push(edge);
    }

    accept(visitor: any): void {
        visitor.visit(this);
    }
}
