if (true) {
    1 + 2;
}