const Foo = function Foo() {
};