switch (42) {
}