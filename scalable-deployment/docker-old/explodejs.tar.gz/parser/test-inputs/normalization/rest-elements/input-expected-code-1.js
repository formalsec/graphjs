const f = function (...args) {
};