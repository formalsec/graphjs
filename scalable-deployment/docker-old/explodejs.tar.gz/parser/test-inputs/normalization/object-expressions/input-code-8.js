var map = { '%r': repo }
